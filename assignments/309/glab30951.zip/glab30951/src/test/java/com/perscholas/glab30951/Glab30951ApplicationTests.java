package com.perscholas.glab30951;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Glab30951ApplicationTests {

	@Test
	void contextLoads() {
	}

}
