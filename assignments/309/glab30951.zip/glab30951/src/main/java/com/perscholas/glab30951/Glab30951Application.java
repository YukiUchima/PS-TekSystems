package com.perscholas.glab30951;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Glab30951Application {

	public static void main(String[] args) {
		SpringApplication.run(Glab30951Application.class, args);
	}

}
